echo "backup local config"
if [ -f /usr/local/srplab/serverapp/starctlcfg.xml ]; then sudo cp -f /usr/local/srplab/serverapp/starctlcfg.xml /usr/local/srplab/serverapp/starctlcfg.xml.old; fi
if [ -f /usr/local/srplab/starenvcfg.xml ]; then sudo cp -f /usr/local/srplab/starenvcfg.xml /usr/local/srplab/starenvcfg.xml.old; fi

if [ -f /usr/local/srplab/starenvcfg.xml ]; then sudo cp -f /usr/local/srplab/starenvcfg.xml /usr/local/srplab/starenvcfg.xml.old; fi
echo "begin install...."

if [ ! -d /usr/local/bin ]; then
  sudo mkdir /usr/local/bin
fi

sudo cp -f usr/local/bin/star2c /usr/local/bin/star2c
sudo cp -f usr/local/bin/star2h /usr/local/bin/star2h
sudo cp -f usr/local/bin/starapp /usr/local/bin/starapp
sudo cp -f usr/local/bin/starctl /usr/local/bin/starctl
sudo cp -f usr/local/bin/starmodule /usr/local/bin/starmodule
sudo cp -f usr/local/bin/starmuser /usr/local/bin/starmuser
sudo cp -f usr/local/bin/starpostinst /usr/local/bin/starpostinst
sudo cp -f usr/local/bin/starregister /usr/local/bin/starregister
sudo cp -f usr/local/bin/starsrvcheck /usr/local/bin/starsrvcheck
sudo cp -f usr/local/bin/starsrvdepend /usr/local/bin/starsrvdepend
sudo cp -f usr/local/bin/starsrvinstinfo /usr/local/bin/starsrvinstinfo
sudo cp -f usr/local/bin/starsrvpack /usr/local/bin/starsrvpack
sudo cp -f usr/local/bin/starsrvparse /usr/local/bin/starsrvparse
sudo cp -f usr/local/bin/starsrvreg /usr/local/bin/starsrvreg
sudo cp -f usr/local/bin/starsrvunparse /usr/local/bin/starsrvunparse

if [ ! -d /usr/local/include ]; then
  sudo mkdir /usr/local/include
fi

sudo rm -rf /usr/local/include/starcore
sudo mkdir /usr/local/include/starcore
sudo mkdir /usr/local/include/starcore/lua
sudo cp -f usr/local/include/starcore/*.h /usr/local/include/starcore
sudo cp -f usr/local/include/starcore/lua/*.h /usr/local/include/starcore/lua

if [ ! -d /usr/local/lib ]; then
  sudo mkdir /usr/local/lib
fi

sudo cp -f usr/local/lib/libstar_java.dylib /usr/local/lib/libstar_java.dylib
sudo cp -f usr/local/lib/libstarcore.dylib /usr/local/lib/libstarcore.dylib
sudo cp -f usr/local/lib/libstarcore53.dylib /usr/local/lib/libstarcore53.dylib
sudo cp -f usr/local/lib/libstarlib.a /usr/local/lib/libstarlib.a


if [ ! -d /usr/local/srplab ]; then
    sudo mkdir /usr/local/srplab
    echo "chmod -R /usr/local/srplab 0777"
    sudo chmod -R 777 /usr/local/srplab
fi
sudo cp -rf usr/local/srplab/. /usr/local/srplab

sudo cp -f uninstall.sh /usr/local/srplab

if [ -f /usr/local/srplab/serverapp/starctlcfg.xml.old ]; then sudo cp -f /usr/local/srplab/serverapp/starctlcfg.xml.old /usr/local/srplab/serverapp/starctlcfg.xml; fi
if [ -f /usr/local/srplab/starenvcfg.xml.old ]; then sudo cp -f /usr/local/srplab/starenvcfg.xml.old /usr/local/srplab/starenvcfg.xml; fi
sudo rm -f /usr/local/srplab/serverapp/starctlcfg.xml.old
sudo rm -f /usr/local/srplab/starenvcfg.xml.old
sudo /usr/local/bin/starpostinst --install_python
echo "install finish"
echo "documents in /usr/local/srplab/docs"
echo "examples in /usr/local/srplab/examples"
echo "license file in /usr/local/srplab"
#echo "if openjava is used, you should create softlink to libjvm.so, for example:"
#echo "    ln -s /usr/lib64/jvm/java-1.6.0-openjdk-1.6.0.0/jre/lib/x86_64/server/libjvm.so /usr/lib64/libjvm.so"
