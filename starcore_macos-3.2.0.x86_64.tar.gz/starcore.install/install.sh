echo "backup local config"
if [ -f /usr/local/srplab/serverapp/starctlcfg.xml ]; then sudo cp -f /usr/local/srplab/serverapp/starctlcfg.xml /usr/local/srplab/serverapp/starctlcfg.xml.old; fi
if [ -f /usr/local/srplab/starenvcfg.xml ]; then sudo cp -f /usr/local/srplab/starenvcfg.xml /usr/local/srplab/starenvcfg.xml.old; fi

if [ -f /usr/local/srplab/starenvcfg.xml ]; then sudo cp -f /usr/local/srplab/starenvcfg.xml /usr/local/srplab/starenvcfg.xml.old; fi
echo "begin install...."

sudo cp -f usr/local/bin/star2c /usr/local/bin
sudo cp -f usr/local/bin/star2h /usr/local/bin
sudo cp -f usr/local/bin/starapp /usr/local/bin
sudo cp -f usr/local/bin/starctl /usr/local/bin
sudo cp -f usr/local/bin/starmodule /usr/local/bin
sudo cp -f usr/local/bin/starmuser /usr/local/bin
sudo cp -f usr/local/bin/starpostinst /usr/local/bin
sudo cp -f usr/local/bin/starregister /usr/local/bin
sudo cp -f usr/local/bin/starsrvcheck /usr/local/bin
sudo cp -f usr/local/bin/starsrvdepend /usr/local/bin
sudo cp -f usr/local/bin/starsrvinstinfo /usr/local/bin
sudo cp -f usr/local/bin/starsrvpack /usr/local/bin
sudo cp -f usr/local/bin/starsrvparse /usr/local/bin
sudo cp -f usr/local/bin/starsrvreg /usr/local/bin
sudo cp -f usr/local/bin/starsrvunparse /usr/local/bin

sudo rm -rf /usr/local/include/starcore
sudo mkdir /usr/local/include/starcore
sudo mkdir /usr/local/include/starcore/lua
sudo cp -f usr/local/include/starcore/*.h /usr/local/include/starcore
sudo cp -f usr/local/include/starcore/lua/*.h /usr/local/include/starcore/lua

sudo cp -f usr/local/lib/libstar_java.dylib /usr/local/lib
sudo cp -f usr/local/lib/libstarcore.dylib /usr/local/lib
sudo cp -f usr/local/lib/libstarcore53.dylib /usr/local/lib
sudo cp -f usr/local/lib/libstarlib.a /usr/local/lib


if [ ! -d /usr/local/srplab ]; then
    sudo mkdir /usr/local/srplab
    echo "chmod -R /usr/local/srplab 0777"
    sudo chmod -R 777 /usr/local/srplab
fi
sudo cp -rf usr/local/srplab/. /usr/local/srplab

sudo cp -f uninstall.sh /usr/local/srplab

if [ -f /usr/local/srplab/serverapp/starctlcfg.xml.old ]; then sudo cp -f /usr/local/srplab/serverapp/starctlcfg.xml.old /usr/local/srplab/serverapp/starctlcfg.xml; fi
if [ -f /usr/local/srplab/starenvcfg.xml.old ]; then sudo cp -f /usr/local/srplab/starenvcfg.xml.old /usr/local/srplab/starenvcfg.xml; fi
sudo rm -f /usr/local/srplab/serverapp/starctlcfg.xml.old
sudo rm -f /usr/local/srplab/starenvcfg.xml.old
sudo /usr/local/bin/starpostinst --install_python
echo "install finish"
echo "documents in /usr/local/srplab/docs"
echo "examples in /usr/local/srplab/examples"
echo "license file in /usr/local/srplab"
#echo "if openjava is used, you should create softlink to libjvm.so, for example:"
#echo "    ln -s /usr/lib64/jvm/java-1.6.0-openjdk-1.6.0.0/jre/lib/x86_64/server/libjvm.so /usr/lib64/libjvm.so"
