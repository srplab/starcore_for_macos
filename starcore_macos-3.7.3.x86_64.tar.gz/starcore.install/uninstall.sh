echo "begin uninstall...."

sudo rm -f /usr/local/bin/star2c
sudo rm -f /usr/local/bin/star2h
sudo rm -f /usr/local/bin/starapp
sudo rm -f /usr/local/bin/starctl
sudo rm -f /usr/local/bin/starmodule
sudo rm -f /usr/local/bin/starmuser
sudo rm -f /usr/local/bin/starpostinst
sudo rm -f /usr/local/bin/starregister
sudo rm -f /usr/local/bin/starsrvcheck
sudo rm -f /usr/local/bin/starsrvdepend
sudo rm -f /usr/local/bin/starsrvinstinfo
sudo rm -f /usr/local/bin/starsrvpack
sudo rm -f /usr/local/bin/starsrvparse
sudo rm -f /usr/local/bin/starsrvreg
sudo rm -f /usr/local/bin/starsrvunparse

sudo rm -rf /usr/local/include/starcore

sudo rm -f /usr/local/lib/libstar_java.dylib
sudo rm -f /usr/local/lib/libstarcore.dylib
sudo rm -f /usr/local/lib/libstarcore53.so
sudo rm -f /usr/local/lib/libstarlib.a

sudo rm -rf /usr/local/srplab

echo "uninstall finish"